import "./Footer.css";
const Footer = () => {
  return (
    <body>
      <div class="footer"> © 2023 Copyright</div>
    </body>
  );
};
export default Footer;
